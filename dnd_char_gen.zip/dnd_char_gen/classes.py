#
#DND 5e Class List
#

#from random import *
import attributes

class_list = ['Barbarian','Bard','Cleric','Druid',
              'Fighter','Monk','Paladin','Ranger',
              'Rogue','Sorcerer','Warlock','Wizard']
#adv_class_list = []
#sub_class_list = []
#homebrew_class_list = []

#class Barbarian:

    
#class Bard:
    
#class Cleric:

#class Druid:
    
#class Fighter:
    
#class Monk:
    
#class Paladin:
    
#class Ranger:

#class Rogue:
    
#class Sorcerer:
    
#class Warlock:
    
#class Wizard:
    
