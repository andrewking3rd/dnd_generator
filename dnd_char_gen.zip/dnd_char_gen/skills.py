#
#DND 5e Skill List
#


strength_skills = []
dexterity_skills = []
constitution_skills = []
intelligence_skills = []
wisdom_skills = []
charisma_skills = []

class Skill:
    skills = []

    def description(self):
        desc_str = "Skill(s): %s" % (*skills, sep = ", ")
        return desc_str

    
    
